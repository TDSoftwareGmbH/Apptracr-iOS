//
//  ApptracrPrivate.h
//  Apptracr
//
//  Created by Manuel Gebele on 31.08.17.
//  Copyright © 2017 TDSoftware GmbH. All rights reserved.
//

#ifndef ApptracrPrivate_h
#define ApptracrPrivate_h

#import "Aspects.h" 

#endif /* ApptracrPrivate_h */
