//
//  ApptracrPrivate.h
//  Apptracr
//
//  Created by Manuel Gebele on 31.08.17.
//

#ifndef ApptracrPrivate_h
#define ApptracrPrivate_h

#import "Aspects.h" 

#endif /* ApptracrPrivate_h */
