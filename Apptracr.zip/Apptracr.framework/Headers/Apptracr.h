//
//  Apptracr.h
//  Apptracr
//
//  Created by Manuel Gebele on 31.08.17.
//

#import <Foundation/Foundation.h>

//! Project version number for Apptracr.
FOUNDATION_EXPORT double ApptracrVersionNumber;

//! Project version string for Apptracr.
FOUNDATION_EXPORT const unsigned char ApptracrVersionString[];
